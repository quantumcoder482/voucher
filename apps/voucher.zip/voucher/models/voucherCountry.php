<?php

use Illuminate\Database\Eloquent\Model;

class voucherCountry extends Model
{
    protected $table = 'voucher_countries'; # Database Table Name


}