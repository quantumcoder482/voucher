<?php

 require 'apps/voucher/models/Voucher.php';
 require 'apps/voucher/models/VoucherCountry.php';

 $action = route(2,'dashboard');
 _auth();
$ui->assign('_application_menu', 'Voucher');
$ui->assign('_title', 'Voucher '.'- '. $config['CompanyName']);
$user = User::_info();
$ui->assign('user', $user);

switch ($action){


    case 'dashboard':

        $countries = Countries::all($config['country']);
        $categories = Array('Silver', 'Gold');

        view('app_wrapper',[
            '_include' => 'dashboard',
            'countries' => $countries
        ]);

//        r2(U.'notes/app/list','s','Deleted successfully');  // redirect url
        break;



    case 'add_list_country':

        $countries = Countries::all($config['country']); // may add this $config['country_code']
        $list_country = ORM::for_table('voucher_country')->order_by_asc('id')->find_array();


        $ui->assign('xheader', Asset::css(array('modal','dp/dist/datepicker.min','footable/css/footable.core.min','dropzone/dropzone','redactor/redactor','s2/css/select2.min')));
        $ui->assign('xfooter', Asset::js(array('modal','dp/dist/datepicker.min','footable/js/footable.all.min','dropzone/dropzone','redactor/redactor.min','numeric','s2/js/select2.min',
            's2/js/i18n/'.lan(),)));
        $ui->assign('xjq', '
            $(\'.amount\').autoNumeric(\'init\', {
            dGroup: ' . $config['thousand_separator_placement'] . ',
            aPad: ' . $config['currency_decimal_digits'] . ',
            pSign: \'' . $config['currency_symbol_position'] . '\',
            aDec: \'' . $config['dec_point'] . '\',
            aSep: \'' . $config['thousands_sep'] . '\',
            vMax: \'9999999999999999.00\',
            vMin: \'-9999999999999999.00\'
            });
            $(\'[data-toggle="tooltip"]\').tooltip();

        ');

        $ui->assign('list_country', $list_country);

        view('app_wrapper',[
            '_include' => 'country_list',
            'countries' => $countries
        ]);


        break;

    case 'modal_edit_country':

        $id= route(3);

        $countries = Countries::all($config['country']); // may add this $config['country_code']
        $country = ORM::for_table('voucher_country')->find_one($id);

        $val=array();

        if($country){
            $val['id']=$id;
            $val['country_name']=$country->country_name;
            $val['prefix']=$country->prefix;
            $val['category']=$country->category;
            $val['description']=$country->description;
            $val['flag']=$country->flag;

        }else{
            $val['id']="";
            $val['country_name']="";
            $val['prefix']="";
            $val['category']="";
            $val['description']="";
            $val['flag']="";
        }



        $baseUrl=APP_URL;
        $ui->assign('countries', $countries);
        $ui->assign('val', $val);
        view('wrapper_modal',[
            '_include'=>'modal_edit_country'
        ]);

        break;

    case 'add_voucher':

        $countries = Countries::all($config['country']); // may add this $config['country_code']
        $country_list = ORM::for_table('voucher_country')->order_by_asc('id')->find_array();

        $ui->assign('xheader', Asset::css(array('modal','dp/dist/datepicker.min','dropzone/dropzone','redactor/redactor','s2/css/select2.min')));
        $ui->assign('xfooter', Asset::js(array('modal','dp/dist/datepicker.min','dropzone/dropzone','redactor/redactor.min','numeric','s2/js/select2.min',
            's2/js/i18n/'.lan(),)));
        $ui->assign('xjq', '
            $(\'.amount\').autoNumeric(\'init\', {
            dGroup: ' . $config['thousand_separator_placement'] . ',
            aPad: ' . $config['currency_decimal_digits'] . ',
            pSign: \'' . $config['currency_symbol_position'] . '\',
            aDec: \'' . $config['dec_point'] . '\',
            aSep: \'' . $config['thousands_sep'] . '\',
            vMax: \'9999999999999999.00\',
            vMin: \'-9999999999999999.00\'
            });
            $(\'[data-toggle="tooltip"]\').tooltip();

        ');

        view('app_wrapper',[
            '_include' => 'add_voucher',
            'countries' => $countries,
            'country_list' => $country_list

        ]);

        break;

    case 'list_voucher':

        $countries = Countries::all($config['country']); // may add this $config['country_code']

        $vouchers = ORM::for_table('voucher_format')->select_many('voucher_format.*','voucher_country.country_name', 'voucher_country.prefix', 'voucher_country.category')
            ->join('voucher_country',array('voucher_country.id','=','voucher_format.country_id'))
            ->order_by_asc('voucher_format.id')
            ->find_many();


        $view_type = 'default';
        $view_type = 'filter';
        $paginator = array();

        $baseUrl = APP_URL;


        $ui->assign('xheader', Asset::css(array('modal','dp/dist/datepicker.min','footable/css/footable.core.min','dropzone/dropzone','redactor/redactor','s2/css/select2.min')));
        $ui->assign('xfooter', Asset::js(array('modal','dp/dist/datepicker.min','footable/js/footable.all.min','dropzone/dropzone','redactor/redactor.min','numeric','s2/js/select2.min',
            's2/js/i18n/'.lan(),)));
        $ui->assign('xjq', '
            $(\'.amount\').autoNumeric(\'init\', {
            dGroup: ' . $config['thousand_separator_placement'] . ',
            aPad: ' . $config['currency_decimal_digits'] . ',
            pSign: \'' . $config['currency_symbol_position'] . '\',
            aDec: \'' . $config['dec_point'] . '\',
            aSep: \'' . $config['thousands_sep'] . '\',
            vMax: \'9999999999999999.00\',
            vMin: \'-9999999999999999.00\'
            });
            $(\'[data-toggle="tooltip"]\').tooltip();

        ');

        $paginator['contents'] = "";


        view('app_wrapper',[
            '_include' => 'list_voucher',
            'vouchers' => $vouchers,
            'view_type' => $view_type,
            'baseUrl' => $baseUrl,
            'paginator' => $paginator
        ]);
        break;

    case 'modal_edit_voucher':

        $id = route(3);

        $voucher = ORM::for_table('voucher_format')->select_many('voucher_format.*','voucher_country.country_name', 'voucher_country.prefix', 'voucher_country.category')
            ->join('voucher_country',array('voucher_country.id','=','voucher_format.country_id'))
            ->order_by_asc('voucher_format.id')
            ->find_one($id);


        view('wrapper_modal',[
           '_include' => 'modal_edit_voucher',
           'voucher' => $voucher

        ]);


        break;

    case 'modal_generate_voucher':

        $id = route(3);
        $voucher = ORM::for_table('voucher_format')->select_many('voucher_format.*','voucher_country.country_name', 'voucher_country.prefix', 'voucher_country.category')
            ->join('voucher_country',array('voucher_country.id','=','voucher_format.country_id'))
            ->order_by_asc('voucher_format.id')
            ->find_one($id);


        $customers = ORM::for_table('crm_accounts')->where_in('type',array('Customer','Customer,Supplier'))->order_by_asc('account')->find_many();
        $suppliers = ORM::for_table('crm_accounts')->where_in('type',array('Supplier','Customer,Supplier'))->order_by_asc('account')->find_many();



        view('wrapper_modal',[
           '_include' => 'modal_generate_voucher',
            'customers' => $customers,
            'suppliers' => $suppliers,
            'voucher' => $voucher,
            'create_invoice' => '',
            'add_payment' => ''
        ]);
        break;

    case 'voucher_transaction':




        break;


    case 'voucher_setting':




        break;


    case 'flagupload':

        if(APP_STAGE == 'Demo'){
            exit;
        }

        $uploader   =   new Uploader();
        $uploader->setDir($app_url.'apps/voucher/public/flags/');
        $uploader->sameName(false);
        $uploader->setExtensions(array('jpg','jpeg','png','gif'));  //allowed extensions list//
        //$uploader->allowAllFormats();  //allowed extensions list//
        if($uploader->uploadFile('file')){   //txtFile is the filebrowse element name //
            $uploaded  =   $uploader->getUploadName(); //get uploaded file name, renames on upload//

            $file = $uploaded;
            $msg = $_L['Uploaded Successfully'];
            $success = 'Yes';

            // create thumb

            $image = new Img();

            // indicate a source image (a GIF, PNG or JPEG file)
            $image->source_path = 'storage/items/'.$file;

            // indicate a target image
            // note that there's no extra property to set in order to specify the target
            // image's type -simply by writing '.jpg' as extension will instruct the script
            // to create a 'jpg' file
            $image->target_path = 'storage/items/thumb'.$file;

            // since in this example we're going to have a jpeg file, let's set the output
            // image's quality
            $image->jpeg_quality = 100;

            // some additional properties that can be set
            // read about them in the documentation
            $image->preserve_aspect_ratio = true;
            $image->enlarge_smaller_images = true;
            $image->preserve_time = true;

            // resize the image to exactly 200x100 pixels by using the "crop from center" method
            // (read more in the overview section or in the documentation)
            //  and if there is an error, check what the error is about
            if (!$image->resize(200, 100, ZEBRA_IMAGE_CROP_CENTER)) {
                // if no errors
            } else {
                // echo 'Success!';
            }

        }else{//upload failed
            $file = '';
            $msg = $uploader->getMessage();
            $success = 'No';
        }

        $a = array(
            'success' => $success,
            'msg' =>$msg,
            'file' =>$file
        );

        header('Content-Type: application/json');
        echo json_encode($a);

        break;


    case 'fileupload':

        if(APP_STAGE == 'Demo'){
            exit;
        }

        $uploader   =   new Uploader();
        $uploader->setDir($app_url.'apps/voucher/public/flags/');
        $uploader->sameName(false);
        $uploader->setExtensions(array('jpg','jpeg','png','gif'));  //allowed extensions list//
        //$uploader->allowAllFormats();  //allowed extensions list//
        if($uploader->uploadFile('file')){   //txtFile is the filebrowse element name //
            $uploaded  =   $uploader->getUploadName(); //get uploaded file name, renames on upload//

            $file = $uploaded;
            $msg = $_L['Uploaded Successfully'];
            $success = 'Yes';

            // create thumb

            $image = new Img();

            // indicate a source image (a GIF, PNG or JPEG file)
            $image->source_path = 'storage/items/'.$file;

            // indicate a target image
            // note that there's no extra property to set in order to specify the target
            // image's type -simply by writing '.jpg' as extension will instruct the script
            // to create a 'jpg' file
            $image->target_path = 'storage/items/thumb'.$file;

            // since in this example we're going to have a jpeg file, let's set the output
            // image's quality
            $image->jpeg_quality = 100;

            // some additional properties that can be set
            // read about them in the documentation
            $image->preserve_aspect_ratio = true;
            $image->enlarge_smaller_images = true;
            $image->preserve_time = true;

            // resize the image to exactly 200x100 pixels by using the "crop from center" method
            // (read more in the overview section or in the documentation)
            //  and if there is an error, check what the error is about
            if (!$image->resize(200, 100, ZEBRA_IMAGE_CROP_CENTER)) {
                // if no errors
            } else {
                // echo 'Success!';
            }

        }else{//upload failed
            $file = '';
            $msg = $uploader->getMessage();
            $success = 'No';
        }

        $a = array(
            'success' => $success,
            'msg' =>$msg,
            'file' =>$file
        );

        header('Content-Type: application/json');
        echo json_encode($a);

        break;


    default:
        echo 'action not defined';
        break;

 }