<?php
$table = new Schema('app_notes');
$table->drop();