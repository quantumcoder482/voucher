<?php
$plugin = [
'name' => 'Voucher',
'author' => 'wu jinhe',
'version' => '1.0.0',
'description' => 'A voucher management system plugin',
'url' => 'https://www.cloudonex.com', # You can put your own website url
'priority' => 1,
'build' => 1000 # Build number if you want to use automatic updates to compare version
];